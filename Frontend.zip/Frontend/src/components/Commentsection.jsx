import React, { useState } from 'react';
import axios from 'axios';

const CommentBox = ({ eventId, comments, onNewComment }) => {
    const [newComment, setNewComment] = useState('');

    const handleAddComment = async () => {
        if (!newComment) return;
        try {
            const response = await axios.post(
                `/api/events/${eventId}/comments`,
                { comment: newComment },
                { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
            );
            if (response.data.success) {
                onNewComment(response.data.comment);
                setNewComment('');
            }
        } catch (err) {
            console.error(err);
            alert('Failed to add comment');
        }
    };

    return (
        <div className="comment-box">
            <h3>Comments</h3>
            <ul>
                {comments.map((c, index) => (
                    <li key={index}>{c.user}: {c.text}</li>
                ))}
            </ul>
            <input
                type="text"
                placeholder="Add a comment..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
            />
            <button onClick={handleAddComment}>Comment</button>
        </div>
    );
};

export default Commentsection;