import React from "react"
import TextField from '@mui/material/TextField';
import {Button} from'@mui/material';
import axios from 'axios';
import { useState } from "react";
import{Link, useNavigate} from 'react-router-dom';

function Signup(){
    const history=useNavigate();
    const [data,setData]=useState(
        {
            name:"",
            email:"",
            password:""
        }
    )
const change=(e)=>{    
    const{name,value}=e.target;
    setData({...data,[name]:value});
}
const handlesubmit=async()=>{
    try {
        if(data.name===""||data.email===""||data.password===""){
            alert("please fill all the fields");
        }
        else{
            const response=await axios.post('http://localhost:3000/api/signup',data);
            
        setData({
            name:"",
            email:"",
            password:""
        });
    
    }
    return(
        <div>
            <TextField label="name" type="name" />
            <TextField label="Email" type="email"/>
            <TextField label="Password" type="password"/>
            <Button>Signup</Button>
        </div>
    )
}
export default Signup
