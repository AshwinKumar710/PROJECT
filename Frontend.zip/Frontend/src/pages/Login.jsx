
import React from "react"
import TextField from '@mui/material/TextField';
import {Button} from'@mui/material';

function Login(){
    return(
        <div>
            <TextField label="name" type="name"/>
            <TextField label="Email" type="email"/>
            <TextField label="Password" type="password"/>
            <Button>Signup</Button>
        </div>
    )
}
export default Login
