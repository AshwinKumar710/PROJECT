const express =require ("express");
const router=express.Router();
const User=require('../models/user');
const bcrypt=require('bcrypt');
router.post('/signup',async(req,res)=>{
    try {
        const {name,email}=req.body;
        const existingUser=await User.findOne({name});
        const existinguser=await User.findOne({email});
        if(existingUser && existinguser){
            return res.status(400).json({error:"user already exists"});
        }
        const hashPassword=await bcrypt.hash(req.body.password,10);
        const newuser=new User({
            name,
            email,
            password:hashPassword
        });
        await newuser.save();
        return res.status(200).json({message:"user created successfully"});
    }
    catch (error) {
        return res.status(500).json({message:"internal server error",error:error.message});
    }
});