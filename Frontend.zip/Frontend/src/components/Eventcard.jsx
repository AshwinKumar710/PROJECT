import React from 'react';
import { useNavigate } from 'react-router-dom';

const EventCard = ({ event }) => {
    const navigate = useNavigate();

    const handleDetails = () => {
        navigate(`/event/${event._id}`);
    };

    return (
        <div className="event-card">
            <h3>{event.title}</h3>
            <p>{event.description}</p>
            <p>Date: {new Date(event.date).toLocaleDateString()}</p>
            <p>Location: {event.location}</p>
            <button onClick={handleDetails}>View Details</button>
        </div>
    );
};

export default Eventcard;