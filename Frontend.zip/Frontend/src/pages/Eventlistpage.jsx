import React from 'react';
import Home1 from './Home1';

const EventList = () => {
    return <HomePage />;
};

export default Eventlistpage;