import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login1 = ({ mode }) => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        name: mode === 'signup' ? '' : null,
        contactNumber: mode === 'signup' ? '' : null,
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const endpoint = mode === 'signup' ? '/api/auth/signup' : '/api/auth/login';
        try {
            const response = await axios.post(endpoint, formData);
            if (response.data.success) {
                localStorage.setItem('token', response.data.token);
                navigate('/home');
            } else {
                alert(response.data.message);
            }
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <div className="form-container">
            <h2>{mode === 'signup' ? 'Sign Up' : 'Login'}</h2>
            <form onSubmit={handleSubmit}>
                {mode === 'signup' && (
                    <>
                        <input type="text" name="name" placeholder="Name" onChange={handleChange} required />
                        <input type="text" name="contactNumber" placeholder="Contact Number" onChange={handleChange} required />
                    </>
                )}
                <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
                <input type="password" name="password" placeholder="Password" onChange={handleChange} required />
                <button type="submit">{mode === 'signup' ? 'Register' : 'Login'}</button>
            </form>
        </div>
    );
};

export default Login1;