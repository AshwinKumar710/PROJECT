import React from 'react';

const Profiledetails = ({ profile }) => {
    return (
        <div className="profile-details">
            <h2>Profile</h2>
            <p><strong>Name:</strong> {profile.name}</p>
            <p><strong>Email:</strong> {profile.email}</p>
            <p><strong>Contact Number:</strong> {profile.contactNumber}</p>
            <p><strong>Registered Events:</strong> {profile.registeredEvents.length}</p>
        </div>
    );
};

export default Profiledetails;