import React, { useState } from 'react';
import Inputdata from '../components/Inputdata';


function ALLtasks() {
    const [inputDiv,setInputDiv]=useState(false)
    function togglefunction(){
        setInputDiv(true)
    }
    return (

        <div style={{textAlign:"left"}}>
            <div>
                <button onClick={togglefunction}>Add Task</button>
            </div>
            {inputDiv && <Inputdata setInputDiv={setInputDiv}/>}
            
            </div>
           
    )
}
export default ALLtasks