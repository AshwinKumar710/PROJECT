import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Admindashboard = () => {
    const [users, setUsers] = useState([]);
    const [events, setEvents] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const userResponse = await axios.get('/api/users');
                const eventResponse = await axios.get('/api/events');
                setUsers(userResponse.data.users);
                setEvents(eventResponse.data.events);
            } catch (err) {
                console.error(err);
            }
        };

        fetchData();
    }, []);

    return (
        <div className="admin-dashboard">
            <h1>Admin Dashboard</h1>
            <h2>Users</h2>
            <ul>
                {users.map(user => (
                    <li key={user._id}>{user.name} - {user.email}</li>
                ))}
            </ul>
            <h2>Events</h2>
            <ul>
                {events.map(event => (
                    <li key={event._id}>{event.title}</li>
                ))}
            </ul>
        </div>
    );
};

export default Admindashboard;