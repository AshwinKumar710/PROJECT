/*import React, { useState, useEffect } from 'react';
import axios from 'axios';

const HomePage = () => {
    const [events, setEvents] = useState([]);

    useEffect(() => {
        const fetchEvents = async () => {
            try {
                const response = await axios.get('/api/events');
                setEvents(response.data.events);
            } catch (err) {
                console.error(err);
            }
        };

        fetchEvents();
    }, []);

    return (
        <div className="home-page">
            <h1>Upcoming Events</h1>
            <div className="event-list">
                {events.map(event => (
                    <div key={event._id} className="event-card">
                        <h3>{event.title}</h3>
                        <p>{event.description}</p>
                        <button onClick={() => window.location.href = /event/${event._id}}>View Details</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Home1;*/


import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Home1 = () => {
    const [events, setEvents] = useState([]);

    useEffect(() => {
        const fetchEvents = async () => {
            try {
                const response = await axios.get('/api/events');
                setEvents(response.data.events);
            } catch (err) {
                console.error(err);
            }
        };

        fetchEvents();
    }, []);

    return (
        <div className="home-page">
            <h1>Upcoming Events</h1>
            <div className="event-list">
                {events.length > 0 ? (
                    events.map(event => (
                        <div key={event._id} className="event-card">
                            <h3>{event.title}</h3>
                            <p>{event.description}</p>
                            <button onClick={() => window.location.href = `/event/${event._id}`}>View Details</button>
                        </div>
                    ))
                ) : (
                    <p>No events found.</p>
                )}
            </div>
        </div>
    );
};

export default Home1;


