
/*import './App.css';
import Home from './pages/Home';
import Signup from './pages/Signup';
import Login from './pages/Login';
import Completetasks from './pages/Completetasks';
import ALLtasks from './pages/ALLtasks';
import Incompletetask from './pages/Incompletetask';
import Importanttasks from './pages/Importanttasks';
import {BrowserRouter as Router,Route,Routes} from "react-router-dom";

function App() {
  return (
    <div className="App">
      
      <Router>
        <Routes>
          <Route path="/" element={<Home/>}>
          <Route index element={<ALLtasks/>}/>
          <Route path='/completetasks' element={<Completetasks/>}/>
          <Route path='/importanttasks' element={<Importanttasks/>}/>
          <Route path='/incompletetask' element={<Incompletetask/>}/>
          </Route>
          <Route path='/signup' element={<Signup/>}/>
          <Route path='/login' element={<Login/>}/>
        </Routes>
      </Router>
    </div>
  );
}*/

/*import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar1 from "./components/Navbar1";
import Home from "./components/Home";
import Login from "./components/Login";
import Signup from "./components/Signup";
import Eventdetails from "./components/Eventdetails";
import Userprofile from "./components/Userprofile";
import Admindashboard from "./components/Admindashboard";


const App = () => {
  return (
    <div className="app-container">
      
      <Router>
        <Navbar1 />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/event/:id" element={<Eventdetails />} />
          <Route path="/profile" element={<Userprofile />} />
          <Route path="/admin" element={<Admindashboard />} />
        </Routes>
      </Router>
    </div>
  );
};

export default App;*/
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar1 from './components/Navbar1';
import Home from './components/Home';
import Login from './components/Login';
import Signup from './components/Signup';
import Eventdetails from './components/Eventdetails';
import Userprofile from './components/Userprofile';
import Admindashboard from './components/Admindashboard';

const App = () => {
  return (
    <div className="app-container">
      <Router>
        <Navbar1 />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/event/:id" element={<Eventdetails />} />
          <Route path="/profile" element={<Userprofile />} />
          <Route path="/admin" element={<Admindashboard />} />
        </Routes>
      </Router>
    </div>
  );
};

export default App;

