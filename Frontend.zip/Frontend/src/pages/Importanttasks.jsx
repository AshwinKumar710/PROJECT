import React from 'react';
function Importanttasks() {
    return (
        <div style={{textAlign:"left"}}>
            <h3>ALL TASKS</h3>
            </div>
    )
}
export default Importanttasks
