import React from 'react'
import { Link } from 'react-router-dom'

function Sidebar() {
    return (
      
      <div style={{display:"flex"}}>
          <div style={{width:"200px",height:"700px",backgroundColor:"Red"}}>
          <div style={{textAlign:"left"}}>
            <Link to="/">
            <button>ALL TASKS</button>
            </Link>
            </div>
            <div style={{textAlign:"left"}}>
            <Link to="/completetask">
            <button>COMPLETED TASKS</button>
            </Link>
            </div>

            <div style={{textAlign:"left"}}>
            <Link to="/incompletetask">
            <button>INCOMPLETE TASKS</button>
            </Link>
            </div>
            <div style={{textAlign:"left"}}>
            <Link to="/importanttasks">
            <button>IMPORTANT TASKS</button>
            </Link>
            </div>
        </div>
      
      
          <div style={{width:"1200px",height:"700px",backgroundColor:"Blue"}}></div>
      
      </div>
      
    )
  }
  
  export default Sidebar