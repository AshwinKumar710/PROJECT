import React, { useState } from 'react';
import axios from 'axios';

const EventForm = ({ onEventAdded }) => {
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        date: '',
        location: '',
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('/api/events', formData, {
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
            });
            if (response.data.success) {
                alert('Event added successfully');
                onEventAdded(response.data.event);
            }
        } catch (err) {
            console.error(err);
            alert('Failed to add event');
        }
    };

    return (
        <form className="event-form" onSubmit={handleSubmit}>
            <h2>Create New Event</h2>
            <input type="text" name="title" placeholder="Event Title" onChange={handleChange} required />
            <textarea name="description" placeholder="Event Description" onChange={handleChange} required />
            <input type="date" name="date" onChange={handleChange} required />
            <input type="text" name="location" placeholder="Location" onChange={handleChange} required />
            <button type="submit">Add Event</button>
        </form>
    );
};

export default Eventform;