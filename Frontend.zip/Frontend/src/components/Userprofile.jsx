import React from "react";

const Userprofile = () => {
  return (
    <div>
      <h2>User Profile</h2>
      <p>Name: Aswin vs</p>
      <p>Email: aswin.vs@example.com</p>
      <p>Registered Events: 3</p>
    </div>
  );
};

export default Userprofile;