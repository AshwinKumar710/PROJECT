/*import React from 'react';
import './Home.css';
import Sidebar from '../components/Sidebar';
import { Outlet } from 'react-router-dom';

function Home() {
  return (
    <div className="home-container">
      

      <div className="content">
        <div className="content-text">Your content goes here</div>
      </div>

      <Outlet />
    </div>
  );
}

export default Home;*/
import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home = () => {
  return (
    <div className="home-container">
      <div className="header">
        <img src="/logo.png" alt="Project Logo" className="logo" /> {/* Add your logo */}
      </div>

      <div className="buttons">
        <button className="button">
          <img src="/icons/login.png" alt="Login Icon" /> Login {/* Add your login icon */}
        </button>
        <button className="button">
          <img src="/icons/signup.png" alt="Signup Icon" /> Signup {/* Add your signup icon */}
        </button>
        <button className="button">
          <img src="/icons/profile.png" alt="Profile Icon" /> Profile {/* Add your profile icon */}
        </button>
      </div>

      <div className="content">
        <div className="content-text">Your content goes here</div>
      </div>

      <Outlet />
    </div>
  );
};

export default Home;


