import React from "react";

const Admindashboard = () => {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Manage events and users.</p>
    </div>
  );
};

export default Admindashboard;