import React from 'react'
import { IoMdClose } from "react-icons/io";

function Inputdata({setInputDiv}) {
    return (
      
      <div style={{display:"flex"}}>
          <div>
          <IoMdClose size={24} color="red" onClick={()=>setInputDiv(false)}/>
            <label>Task</label>
            <input/>
            <button>Add task</button>
            
          </div>
      
          <div style={{width:"1200px",height:"700px",backgroundColor:"Blue"}}></div>
          
           
        
      
      </div>
      
    )
  }
  
  export default Inputdata