import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UserProfile = () => {
    const [profile, setProfile] = useState(null);

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const response = await axios.get('/api/users/me', {
                    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
                });
                setProfile(response.data.user);
            } catch (err) {
                console.error(err);
            }
        };

        fetchProfile();
    }, []);

    if (!profile) return <p>Loading...</p>;

    return (
        <div className="user-profile">
            <h1>{profile.name}</h1>
            <p>Email: {profile.email}</p>
            <p>Contact: {profile.contactNumber}</p>
        </div>
    );
};

export default UserProfile;