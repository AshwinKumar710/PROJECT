import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const EventDetails = () => {
    const { id } = useParams();
    const [event, setEvent] = useState(null);

    useEffect(() => {
        const fetchEvent = async () => {
            try {
                const response = await axios.get(/api/events/${id});
                setEvent(response.data.event);
            } catch (err) {
                console.error(err);
            }
        };

        fetchEvent();
    }, [id]);

    if (!event) return <p>Loading...</p>;

    return (
        <div className="event-details">
            <h1>{event.title}</h1>
            <p>{event.description}</p>
            <p>Date: {new Date(event.date).toLocaleDateString()}</p>
            <p>Location: {event.location}</p>
        </div>
    );
};

export default Eventdetailspage;