import React from 'react';
function Incompletetask() {
    return (
        <div style={{textAlign:"left"}}>
            <h3>ALL TASKS</h3>
            </div>
    )
}
export default Incompletetask