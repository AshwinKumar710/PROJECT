import React from 'react';

const UserList = ({ users, onBlockUser }) => {
    return (
        <div className="user-list">
            <h3>User List</h3>
            <ul>
                {users.map(user => (
                    <li key={user._id}>
                        {user.name} ({user.email})
                        <button onClick={() => onBlockUser(user._id)}>Block</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Userlist;